import java.io.*;
import java.util.Scanner;


public class file {



    public static void main(String[] args) throws IOException {
 account callAccount=new account();
        Reads call=new Reads();
        writes callWrites=new writes();
            Login callLogin=new Login();


callAccount.accountRegister();
callWrites.write();
//callLogin.login();








    }



}
